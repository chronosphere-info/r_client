## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(chronosphere)

## ----package, echo= TRUE, eval=FALSE-------------------------------------
#  library(chronosphere)

## ----demO, echo= TRUE----------------------------------------------------
data(demo)

## ----demOout, echo= TRUE-------------------------------------------------
demo

## ----tsplot1, echo= TRUE, plot=TRUE, fig.height=5.5----------------------
mapplot(demo[1], col="earth")

